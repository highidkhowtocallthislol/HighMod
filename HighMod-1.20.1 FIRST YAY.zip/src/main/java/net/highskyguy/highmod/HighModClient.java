package net.highskyguy.highmod;
import net.fabricmc.api.ClientModInitializer;

public class HighModClient implements ClientModInitializer{
    @Override
    public void onInitializeClient() {

    }
}
