package net.highskyguy.highmod.block;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.highskyguy.highmod.HighMod;
import net.highskyguy.highmod.block.custom.SoundBlock;
import net.minecraft.block.*;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2378;
import net.minecraft.class_2431;
import net.minecraft.class_2440;
import net.minecraft.class_2482;
import net.minecraft.class_2498;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2960;
import net.minecraft.class_3620;
import net.minecraft.class_4719;
import net.minecraft.class_6019;
import net.minecraft.class_7923;
import net.minecraft.class_8177;

public class ModBlocks {

    public static final class_2248 RUBY_BLOCK = registerBlock("ruby_block",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10085).method_9629(5.0F, 20.5F)
                    .method_31710(class_3620.field_25702)
                    .method_9626(class_2498.field_11544)));
    public static final class_2248 RAW_RUBY_BLOCK = registerBlock("raw_ruby_block",
            new class_2248(FabricBlockSettings.copyOf(class_2246.field_10085).method_9629(5.0F, 10.0F)
                    .method_31710(class_3620.field_25708)
                    .method_9626(class_2498.field_22151)));
    public static final class_2248 RUBY_ORE = registerBlock("ruby_ore",
            new class_2431(FabricBlockSettings.copyOf(class_2246.field_10340).method_9629(2.0F,10.0F), class_6019.method_35017(10, 1000)));
    public static final class_2248 DEEPSLATE_RUBY_ORE = registerBlock("deepslate_ruby_ore",
            new class_2431(FabricBlockSettings.copyOf(class_2246.field_28888).method_9629(4.0F,10.0F), class_6019.method_35017(10, 1000)));
    public static final class_2248 NETHER_RUBY_ORE = registerBlock("nether_ruby_ore",
            new class_2431(FabricBlockSettings.copyOf(class_2246.field_10515).method_9629(1.0F,10.0F), class_6019.method_35017(10, 1000)));
    public static final class_2248 END_RUBY_ORE = registerBlock("end_stone_ruby_ore",
            new class_2431(FabricBlockSettings.copyOf(class_2246.field_10471).method_9629(2.0F,10.0F), class_6019.method_35017(10, 1000)));
    public static final class_2248 SOUND_BLOCK = registerBlock("sound_block",
            new SoundBlock(FabricBlockSettings.copyOf(class_2246.field_9987)));
    public static final class_2248 RUBY_STAIRS = registerBlock("ruby_stairs",
            new class_2510( ModBlocks.RUBY_BLOCK.method_9564() ,FabricBlockSettings.copyOf(class_2246.field_10340)));
    public static final class_2248 RUBY_SLAB = registerBlock("ruby_slab",
            new class_2482(FabricBlockSettings.copyOf(class_2246.field_10340)));
    public static final class_2248 RUBY_BUTTON = registerBlock("ruby_button",
            new class_2269( FabricBlockSettings.copyOf(class_2246.field_10340), class_8177.field_42821, 10, true));
    public static final class_2248 RUBY_PRESSURE_PLATE = registerBlock("ruby_pressure_plate",
            new class_2440( class_2440.class_2441.field_11361 ,FabricBlockSettings.copyOf(class_2246.field_10340), class_8177.field_42821));
    public static final class_2248 RUBY_FENCE = registerBlock("ruby_fence",
            new class_2354(FabricBlockSettings.copyOf(class_2246.field_10340)));
    public static final class_2248 RUBY_FENCE_GATE  = registerBlock("ruby_fence_gate",
            new class_2349(FabricBlockSettings.copyOf(class_2246.field_10340), class_4719.field_21676));
    public static final class_2248 RUBY_DOOR = registerBlock("ruby_door",
            new class_2323(FabricBlockSettings.copyOf(class_2246.field_10340), class_8177.field_42823));
    public static final class_2248 RUBY_TRAPDOOR = registerBlock("ruby_trapdoor",
            new class_2533(FabricBlockSettings.copyOf(class_2246.field_10340), class_8177.field_42823));
    public static final class_2248 RUBY_WALL = registerBlock("ruby_wall",
            new class_2544(FabricBlockSettings.copyOf(class_2246.field_10340)));


    private static class_2248 registerBlock(String name, class_2248 block){
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, new class_2960(HighMod.MOD_ID, name), block);
    }

    private static class_1792 registerBlockItem(String name, class_2248 block){
        return class_2378.method_10230(class_7923.field_41178, new class_2960(HighMod.MOD_ID, name),
                new class_1747(block, new FabricItemSettings()));
    }

    public static void registerModBlocks(){
        HighMod.LOGGER.info("Registering Mod Blocks: " + HighMod.MOD_ID);
    }
}
