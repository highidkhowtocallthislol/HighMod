package net.highskyguy.highmod.block.custom;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;


public class SoundBlock extends class_2248 {
    public SoundBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {
        world.method_8396(player, pos, class_3417.field_15151, class_3419.field_15245, 1f, 1f);
        return class_1269.field_5812;
    }

    @Override
    public void method_9568(class_1799 stack, @Nullable class_1922 world, List<class_2561> tooltip, class_1836 options) {
        tooltip.add(class_2561.method_43471("highmod.tooltip.sound_block"));
        super.method_9568(stack, world, tooltip, options);
    }
}
