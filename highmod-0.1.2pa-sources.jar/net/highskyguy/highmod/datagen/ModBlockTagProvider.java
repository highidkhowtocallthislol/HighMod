package net.highskyguy.highmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.highskyguy.highmod.block.ModBlocks;
import net.highskyguy.highmod.util.ModTags;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import java.util.concurrent.CompletableFuture;

public class ModBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public ModBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(ModTags.Blocks.METAL_DETECTOR_DETECTABLE_BLOCKS)
                .add(ModBlocks.RUBY_ORE)
                .forceAddTag(class_3481.field_23062)
                .forceAddTag(class_3481.field_29194)
                .forceAddTag(class_3481.field_28990)
                .forceAddTag(class_3481.field_28991)
                .forceAddTag(class_3481.field_28989)
                .forceAddTag(class_3481.field_28988)
                .forceAddTag(class_3481.field_29195)
                .forceAddTag(class_3481.field_29193);

        method_10512(class_3481.field_33715)
                .add(ModBlocks.RAW_RUBY_BLOCK)
                .add(ModBlocks.RUBY_BLOCK)
                .add(ModBlocks.RUBY_ORE)
                .add(ModBlocks.DEEPSLATE_RUBY_ORE)
                .add(ModBlocks.NETHER_RUBY_ORE)
                .add(ModBlocks.END_RUBY_ORE)
                .add(ModBlocks.SOUND_BLOCK)
                .add(ModBlocks.RUBY_TRAPDOOR)
                .add(ModBlocks.RUBY_BUTTON)
                .add(ModBlocks.RUBY_FENCE)
                .add(ModBlocks.RUBY_FENCE_GATE)
                .add(ModBlocks.RUBY_DOOR)
                .add(ModBlocks.RUBY_STAIRS)
                .add(ModBlocks.RUBY_SLAB)
                .add(ModBlocks.RUBY_PRESSURE_PLATE)
                .add(ModBlocks.RUBY_WALL);





        method_10512(class_3481.field_33719)
                .add(ModBlocks.RUBY_BLOCK)
                .add(ModBlocks.RUBY_TRAPDOOR)
                .add(ModBlocks.RUBY_BUTTON)
                .add(ModBlocks.RUBY_FENCE)
                .add(ModBlocks.RUBY_FENCE_GATE)
                .add(ModBlocks.RUBY_DOOR)
                .add(ModBlocks.RUBY_STAIRS)
                .add(ModBlocks.RUBY_SLAB)
                .add(ModBlocks.RUBY_PRESSURE_PLATE)
                .add(ModBlocks.RUBY_WALL);
        method_10512(class_3481.field_33718)
                .add(ModBlocks.RAW_RUBY_BLOCK)
                .add(ModBlocks.RUBY_ORE)
                .add(ModBlocks.RUBY_TRAPDOOR)
                .add(ModBlocks.RUBY_BUTTON)
                .add(ModBlocks.RUBY_FENCE)
                .add(ModBlocks.RUBY_FENCE_GATE)
                .add(ModBlocks.RUBY_DOOR)
                .add(ModBlocks.RUBY_STAIRS)
                .add(ModBlocks.RUBY_SLAB)
                .add(ModBlocks.RUBY_PRESSURE_PLATE)
                .add(ModBlocks.RUBY_WALL);

        method_10512(class_3481.field_33717)
                .add(ModBlocks.DEEPSLATE_RUBY_ORE)
                .add(ModBlocks.RUBY_TRAPDOOR)
                .add(ModBlocks.RUBY_BUTTON)
                .add(ModBlocks.RUBY_FENCE)
                .add(ModBlocks.RUBY_FENCE_GATE)
                .add(ModBlocks.RUBY_DOOR)
                .add(ModBlocks.RUBY_STAIRS)
                .add(ModBlocks.RUBY_SLAB)
                .add(ModBlocks.RUBY_PRESSURE_PLATE)
                .add(ModBlocks.RUBY_WALL);

        method_10512(class_6862.method_40092(class_7924.field_41254, new class_2960("fabric", "needs_tool_level_4")))
                .add(ModBlocks.END_RUBY_ORE);
        method_10512(class_6862.method_40092(class_7924.field_41254, new class_2960("fabric", "needs_tool_level_5")))
                .add(ModBlocks.END_RUBY_ORE);


        method_10512(class_3481.field_16584)
                .add(ModBlocks.RUBY_FENCE);
        method_10512(class_3481.field_25147)
                .add(ModBlocks.RUBY_FENCE_GATE);
        method_10512(class_3481.field_15504)
                .add(ModBlocks.RUBY_WALL);
    }
}