package net.highskyguy.highmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.highskyguy.highmod.block.ModBlocks;
import net.highskyguy.highmod.item.ModItems;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_52;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.minecraft.class_7788;
import net.minecraft.class_79;
import net.minecraft.class_85;
import net.minecraft.class_94;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void method_10379() {
        method_46025(ModBlocks.RUBY_BLOCK);
        method_46025(ModBlocks.RAW_RUBY_BLOCK);
        method_46025(ModBlocks.SOUND_BLOCK);

        method_45988(ModBlocks.RUBY_ORE, copperLikeOreDrops(ModBlocks.RUBY_ORE, ModItems.RAW_RUBY));
        method_45988(ModBlocks.DEEPSLATE_RUBY_ORE, copperLikeOreDrops(ModBlocks.DEEPSLATE_RUBY_ORE, ModItems.RAW_RUBY));
        method_45988(ModBlocks.NETHER_RUBY_ORE, copperLikeOreDrops(ModBlocks.NETHER_RUBY_ORE, ModItems.RAW_RUBY));
        method_45988(ModBlocks.END_RUBY_ORE, copperLikeOreDrops(ModBlocks.END_RUBY_ORE, ModItems.RAW_RUBY));


        method_46025(ModBlocks.RUBY_STAIRS);
        method_46025(ModBlocks.RUBY_TRAPDOOR);
        method_46025(ModBlocks.RUBY_WALL);
        method_46025(ModBlocks.RUBY_FENCE);
        method_46025(ModBlocks.RUBY_FENCE_GATE);
        method_46025(ModBlocks.RUBY_BUTTON);
        method_46025(ModBlocks.RUBY_PRESSURE_PLATE);

        method_45988(ModBlocks.RUBY_DOOR, method_46022(ModBlocks.RUBY_DOOR));
        method_45988(ModBlocks.RUBY_SLAB, method_45980(ModBlocks.RUBY_SLAB));

    }

    public class_52.class_53 copperLikeOreDrops(class_2248 drop, class_1792 item) {
        return class_7788.method_45989(drop, (class_79.class_80)this.method_45977(drop,
                ((class_85.class_86)
                        class_77.method_411(item)
                                .method_438(class_141
                                        .method_621(class_5662
                                                .method_32462(2.0f, 5.0f))))
                        .method_438(class_94.method_455(class_1893.field_9130))));
    }
}
