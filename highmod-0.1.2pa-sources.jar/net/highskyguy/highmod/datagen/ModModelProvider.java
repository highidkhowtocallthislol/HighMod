package net.highskyguy.highmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.highskyguy.highmod.block.ModBlocks;
import net.highskyguy.highmod.item.ModItems;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4943;

public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        class_4910.class_4912 rubyPool = blockStateModelGenerator.method_25650(ModBlocks.RUBY_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.RAW_RUBY_BLOCK);
        blockStateModelGenerator.method_25641(ModBlocks.RUBY_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.DEEPSLATE_RUBY_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.NETHER_RUBY_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.END_RUBY_ORE);
        blockStateModelGenerator.method_25641(ModBlocks.SOUND_BLOCK);

        rubyPool.method_25725(ModBlocks.RUBY_STAIRS);
        rubyPool.method_25724(ModBlocks.RUBY_SLAB);
        rubyPool.method_25716(ModBlocks.RUBY_BUTTON);
        rubyPool.method_25723(ModBlocks.RUBY_PRESSURE_PLATE);
        rubyPool.method_25721(ModBlocks.RUBY_FENCE);
        rubyPool.method_25722(ModBlocks.RUBY_FENCE_GATE);
        rubyPool.method_25720(ModBlocks.RUBY_WALL);

        blockStateModelGenerator.method_25658(ModBlocks.RUBY_DOOR);
        blockStateModelGenerator.method_25671(ModBlocks.RUBY_TRAPDOOR);

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_25733(ModItems.RUBY, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RAW_RUBY, class_4943.field_22938);

        itemModelGenerator.method_25733(ModItems.MY_GYATT, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.TOMATO, class_4943.field_22938);
        itemModelGenerator.method_25733(ModItems.RUBY_PICKAXE, class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RUBY_AXE, class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RUBY_SWORD, class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RUBY_HOE, class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.RUBY_SHOVEL, class_4943.field_22939);
        itemModelGenerator.method_25733(ModItems.METAL_DETECTOR, class_4943.field_22938);
    }
}
