package net.highskyguy.highmod.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.highskyguy.highmod.block.ModBlocks;
import net.highskyguy.highmod.item.ModItems;
import net.minecraft.class_1802;
import net.minecraft.class_1935;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2960;
import net.minecraft.class_7800;
import java.util.List;
import java.util.function.Consumer;

public class ModRecipeProvider extends FabricRecipeProvider {
    private static final List<class_1935> RUBY_SMELTABLES = List.of(ModItems.RAW_RUBY,
            ModBlocks.RUBY_ORE, ModBlocks.DEEPSLATE_RUBY_ORE, ModBlocks.NETHER_RUBY_ORE, ModBlocks.END_RUBY_ORE);

    public ModRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> exporter) {
        method_36233(exporter, RUBY_SMELTABLES, class_7800.field_40642, ModItems.RUBY,
                0.7f, 200, "ruby");
        method_36234(exporter, RUBY_SMELTABLES, class_7800.field_40642, ModItems.RUBY,
                0.7f, 100, "ruby");

        method_36325(exporter, class_7800.field_40634, ModItems.RUBY, class_7800.field_40635,
                ModBlocks.RUBY_BLOCK);

        class_2447.method_10436(class_7800.field_40642, ModItems.RAW_RUBY, 1)
                .method_10439("SSS")
                .method_10439("SRS")
                .method_10439("SSS")
                .method_10434('S', class_1802.field_20391)
                .method_10434('R', ModItems.RUBY)
                .method_10429(method_32807(class_1802.field_20391), method_10426(class_1802.field_20391))
                .method_10429(method_32807(ModItems.RUBY), method_10426(ModItems.RUBY))
                .method_17972(exporter, new class_2960(method_36450(ModItems.RAW_RUBY)));
        
    }
}