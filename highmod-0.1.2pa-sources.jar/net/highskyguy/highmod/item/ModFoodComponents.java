package net.highskyguy.highmod.item;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_4174;

public class ModFoodComponents {
    public static final class_4174 TOMATO = new class_4174.class_4175().method_19238(10).method_19237(100f)
            .method_19239(new class_1293(class_1294.field_5915, 999999999, 100000),100f)
            .method_19236()
            .method_19242() ;

}
