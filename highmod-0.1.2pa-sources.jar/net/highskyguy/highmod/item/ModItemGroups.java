package net.highskyguy.highmod.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.highskyguy.highmod.HighMod;
import net.highskyguy.highmod.block.ModBlocks;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModItemGroups {
    public static final class_1761 RUBY_GROUP = class_2378.method_10230(class_7923.field_44687,
            new class_2960(HighMod.MOD_ID, "ruby"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("itemgroup.ruby"))
                    .method_47320(() -> new class_1799(ModItems.RUBY)).method_47317((displayContext, entries) -> {
                        entries.method_45421(ModItems.RUBY);
                        entries.method_45421(ModItems.RAW_RUBY);
                        entries.method_45421(ModBlocks.RUBY_BLOCK);
                        entries.method_45421(ModBlocks.NETHER_RUBY_ORE);
                        entries.method_45421(ModBlocks.END_RUBY_ORE);
                        entries.method_45421(ModBlocks.DEEPSLATE_RUBY_ORE);
                        entries.method_45421(ModBlocks.RUBY_ORE);
                        entries.method_45421(ModItems.METAL_DETECTOR);
                        entries.method_45421(ModBlocks.SOUND_BLOCK);
                        // If you are reading the source, sound block is inherited from the bedrock mining profile which is impossible to mine.
                        entries.method_45421(ModItems.TOMATO);
                        entries.method_45421(ModItems.MY_GYATT);
                        entries.method_45421(ModItems.RUBY_PICKAXE);
                        entries.method_45421(ModItems.RUBY_AXE);
                        entries.method_45421(ModItems.RUBY_HOE);
                        entries.method_45421(ModItems.RUBY_SHOVEL);
                        entries.method_45421(ModItems.RUBY_SWORD);
                        entries.method_45421(ModBlocks.RUBY_TRAPDOOR);
                        entries.method_45421(ModBlocks.RUBY_BUTTON);
                        entries.method_45421(ModBlocks.RUBY_FENCE);
                        entries.method_45421(ModBlocks.RUBY_FENCE_GATE);
                        entries.method_45421(ModBlocks.RUBY_DOOR);
                        entries.method_45421(ModBlocks.RUBY_STAIRS);
                        entries.method_45421(ModBlocks.RUBY_SLAB);
                        entries.method_45421(ModBlocks.RUBY_PRESSURE_PLATE);
                        entries.method_45421(ModBlocks.RUBY_WALL);
                    }).method_47324());
    public static final class_1761 ILLEGAL_GROUP = class_2378.method_10230(class_7923.field_44687,
            new class_2960(HighMod.MOD_ID, "metal_detector"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("itemgroup.illegal"))
                    .method_47320(() -> new class_1799(ModItems.RUBY)).method_47317((displayContext, entries) -> {
                       entries.method_45421(class_1802.field_8866);
                       entries.method_45421(class_1802.field_8799);
                       entries.method_45421(class_1802.field_8468);
                       entries.method_45421(class_1802.field_8849);
                       entries.method_45421(class_1802.field_8827);





                    }).method_47324());

    public static void registerItemGroups() {
        HighMod.LOGGER.info("Registering Item Groups for " + HighMod.MOD_ID);
    }
}

