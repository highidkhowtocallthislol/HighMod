package net.highskyguy.highmod.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.highskyguy.highmod.HighMod;
import net.highskyguy.highmod.item.custom.MetalDetectorItem;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1810;
import net.minecraft.class_1821;
import net.minecraft.class_1829;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.item.*;

public class ModItems {
    public static final class_1792 RUBY = registerItem("ruby", new class_1792(new FabricItemSettings()));
    public static final class_1792 RAW_RUBY = registerItem("raw_ruby", new class_1792(new FabricItemSettings()));
    public static final class_1792 METAL_DETECTOR = registerItem("metal_detector",
            new MetalDetectorItem(new FabricItemSettings().method_7895(1000)));
    public static final class_1792 TOMATO = registerItem("tomato", new class_1792(new FabricItemSettings().method_19265(ModFoodComponents.TOMATO)));
    public static final class_1792 MY_GYATT = registerItem("juicy_gyatts_totally_not_for_grilling_meat_i_dont_know_haha", new class_1792(new FabricItemSettings()));
    public static final class_1792 RUBY_PICKAXE = registerItem("ruby_pickaxe",
            new class_1810( ModToolMaterial.RUBY , 100, 100f,new
                    FabricItemSettings()));
    public static final class_1792 RUBY_AXE = registerItem("ruby_axe",
            new class_1743( ModToolMaterial.RUBY , 100000000, 100000f,new
                    FabricItemSettings()));
    public static final class_1792 RUBY_SWORD = registerItem("ruby_sword",
            new class_1829( ModToolMaterial.RUBY , 100000, 10000f,new
                    FabricItemSettings()));
    public static final class_1792 RUBY_HOE = registerItem("ruby_hoe",
            new class_1794( ModToolMaterial.RUBY , 1, 100f,new
                    FabricItemSettings()));
    public static final class_1792 RUBY_SHOVEL = registerItem("ruby_shovel",
            new class_1821( ModToolMaterial.RUBY , 1, 100f,new
                    FabricItemSettings()));
    private static void addItemsToIngredientItemGroup(FabricItemGroupEntries entries) {
        entries.method_45421(RUBY);
        entries.method_45421(RAW_RUBY);
        entries.method_45421(METAL_DETECTOR);
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(HighMod.MOD_ID, name), item);
    }

    public static void registerModItems() {
        HighMod.LOGGER.info("Registering Mod Items for " + HighMod.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(ModItems::addItemsToIngredientItemGroup);
    }
}