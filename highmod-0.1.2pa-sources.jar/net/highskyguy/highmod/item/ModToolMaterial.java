package net.highskyguy.highmod.item;

import net.fabricmc.yarn.constants.MiningLevels;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import java.util.function.Supplier;

public enum ModToolMaterial implements class_1832 {
    RUBY(5,650,5f,100f,15, () -> class_1856.method_8091(ModItems.RUBY))
    ;

    private final int miningLevel;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Supplier<class_1856> repairIngredient;

    ModToolMaterial(int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<class_1856> repairIngredient) {
        this.miningLevel = miningLevel;
        this.itemDurability = itemDurability;
        this.miningSpeed = miningSpeed;
        this.attackDamage = attackDamage;
        this.enchantability = enchantability;
        this.repairIngredient = repairIngredient;
    }


    @Override
    public int method_8025() {
        return this.itemDurability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public int method_8024() {
        return this.miningLevel;
    }

    @Override
    public int method_8026() {
        return this.enchantability;
    }

    @Override
    public class_1856 method_8023() {
        return this.repairIngredient.get();
    }
}
