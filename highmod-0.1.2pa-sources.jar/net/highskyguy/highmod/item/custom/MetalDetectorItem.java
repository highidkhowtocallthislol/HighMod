package net.highskyguy.highmod.item.custom;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;

public class MetalDetectorItem extends class_1792 {

    public MetalDetectorItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        if(!context.method_8045().method_8608()){
            class_2338 positionClicked = context.method_8037();
            class_1657 player = context.method_8036();
            boolean foundBlock = false;

            for(int i = 0; i <= positionClicked.method_10264() + 64; i++){
                class_2680 state = context.method_8045().method_8320(positionClicked.method_10087(i));

                if(isValuableBlock(state)){
                outputValuableCoordinates(positionClicked.method_10087(i), player, state.method_26204());
                foundBlock = true;

                break;
                }
            }
            if(!foundBlock){
                player.method_43496(class_2561.method_43470("No Iron, Diamond nor Ancient Debris were found!"));
            }
        }
        context.method_8041().method_7956(1, context.method_8036(),
                playerEntity -> playerEntity.method_20236(playerEntity.method_6058()));


        return class_1269.field_5812;
    }

    private void outputValuableCoordinates(class_2338 blockPos, class_1657 player, class_2248 block) {
        player.method_7353(class_2561.method_43470("Found " + block.method_8389().method_7848().getString() + " at " +
                "(" + blockPos.method_10263() + ", " + blockPos.method_10264() + ", " + blockPos.method_10260() + ")"), false);
    }

    private boolean isValuableBlock(class_2680 state) {
        return state.method_27852(class_2246.field_10212) || state.method_27852(class_2246.field_10442) || state.method_27852(class_2246.field_22109);
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        tooltip.add(class_2561.method_43471("highmod.tooltip.iron_detector"));
        super.method_7851(stack, world, tooltip, context);
    }
}
